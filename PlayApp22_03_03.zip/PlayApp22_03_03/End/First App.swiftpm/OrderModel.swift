import Foundation

struct OrderItem:Identifiable{
    enum Size{
        case small,medium,large,xtraLarge
    }
    var item:MenuItem
    var quantity:Int = 0
    var size:Size = .medium
    var id = UUID()
    var extPrice:Double{
        Double(quantity) * item.price
    }
}

class OrderModel{
    /// An array of `OrderItem` 
    var items:[OrderItem] = []
    /// The current count of orders
    var count:Int{
        items.count
    }
    
    /// Initialize with an array of items
    ///  - Parameter items: An Array of `OrderItems`
    init(items:[OrderItem]){
        self.items = items
    }
    
    /// The grand total of the orders
    var total:Double{
        var sum:Double = 0.0
        for item in items{
            sum += item.extPrice
        }
        return sum
    }
    /// Add a order item
    /// - Parameter: item an `OrderItem` 
    func add(item:OrderItem){
        items.append(item)
    }
    /// Add a menu item and quantity as an order item
    /// - Parameter item: a `MenuItem`
    /// - Parameter quantity: the number of items
    func add(item:MenuItem,quantity:Int){
        let orderItem = OrderItem(item: item,quantity: quantity)
        add(item: orderItem)
    }
    /// Remove an item
    ///  - Parameter item: the Item to remove
    func remove(item:OrderItem!){
        if item == nil {return}
        let id = item.id
        if let index = items.firstIndex(where:{ (i) -> Bool in i.id == id}) {
            items.remove(at: index)
        }
    }

    
    
}
