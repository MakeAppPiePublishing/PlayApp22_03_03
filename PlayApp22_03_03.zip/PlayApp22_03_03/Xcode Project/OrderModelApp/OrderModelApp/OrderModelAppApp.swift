//
//  OrderModelAppApp.swift
//  OrderModelApp
//
//  Created by Steven Lipton on 7/30/22.
//

import SwiftUI

@main
struct OrderModelAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(orders: OrderModel(items:[]))
        }
    }
}
