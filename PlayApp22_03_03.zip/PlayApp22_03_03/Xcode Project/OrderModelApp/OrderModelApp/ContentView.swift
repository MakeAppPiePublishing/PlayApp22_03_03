//
//  ContentView.swift
//  OrderModelApp
//
//  Created by Steven Lipton on 7/30/22.
//

import SwiftUI
struct ContentView: View {
    var menu:[MenuItem] = MenuModel().menu
    @State var orders:OrderModel
    @State private var orderTotal:Double = 0
    var body: some View {
        VStack {
            Text((orderTotal.formatted(.currency(code: "USD"))))
            OrderView(model: $orders, orderTotal: $orderTotal)
                .padding()
            SelectView(menu: menu, orders: $orders)
            Button {
                orders.add(item: testMenuItem, quantity: 3)
                orderTotal = orders.total
            } label: {
                Text("Order Pizza")
            }

        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(orders:OrderModel(items: [OrderItem(item: testMenuItem,quantity: 2)]))
    }
}
