//
//  SelectView.swift
//  OrderModelApp
//
//  Created by Steven Lipton on 7/30/22.
//

import SwiftUI

struct SelectView: View {
    @State var bkgrnd:Bool = false
    var menu:[MenuItem]
    @Binding var orders:OrderModel
    var body: some View {
        VStack{
            ScrollView{
                ForEach(menu){ item in
                    HStack{
                        Text(item.name)
                            .font(.headline)
                            .padding()
                        Spacer()
                        Image(systemName: "plus")
                            .onTapGesture(perform: {
                                bkgrnd.toggle()
                                orders.add(item: item, quantity: 1)
                            })
                            .padding()
                    }
                    .background(bkgrnd ? Color.blue : Color.green)
                    
                }
            }
            HStack{
                ForEach(orders.items){ item in
                    Text(item.item.name).font(.caption)
                }
            }
        }
        
    }
}

struct SelectView_Previews: PreviewProvider {
    static var previews: some View {
        SelectView(menu: MenuModel().menu, orders: .constant(OrderModel(items: [OrderItem(item: testMenuItem)]) ))
    }
}

